let typeEntity;

function toggleMenu(id){
	let idMenu = document.getElementById(id);
	let message = document.getElementById("message");
	let form = document.getElementById("form");
	
	if(idMenu.classList.contains("hidden")){
		idMenu.classList.remove("hidden");
		message.classList.add("hidden");
		form.classList.remove("hidden");
		typeEntity = id;
		console.log(typeEntity)
	}else{
		idMenu.classList.add("hidden");
		message.classList.remove("hidden");
		form.classList.add("hidden");
	}
}

function toggleForm(entity, object, url){
	
	let form = document.getElementById("form")
	
	//TODO: Hacer que el formulario se muestrar para hacer el crud de las entidades
	
	form.innerHTML = `
	<form action='#' th:action="'@{${url}}'" th:object='${object}'>
						
	</form>
	`
	
}

function showForm(url, object){
	
	console.log(url)
	
	switch(typeEntity){
		case 'peliculas':
			toggleForm('peliculas', object, url)
		case 'sedes':
			toggleForm('sedes', object, url)
	}
}

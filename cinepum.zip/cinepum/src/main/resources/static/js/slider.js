import { tns } from './tiny-slider.js';

let slider = tns({
        "container": ".movies-carousel",
        "items": 3,
        "center": true,
        "gutter": 20,
        "mode": "carousel",
        "mouseDrag": true,
        "swipeAngle": false,
        "speed": 300,
        "autoplay": true,
        "autoplayHoverPause": false,
        "autoplayTimeout": 3500,
        "controls": false,
        "controlsText": false,
        "autoplayButton": false,
        "autoplayButtonOutput": false,
        "responsive": {
            "640": {
                "items": 5
            }
        }
});
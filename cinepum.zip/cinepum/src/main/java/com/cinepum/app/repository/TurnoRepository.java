package com.cinepum.app.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cinepum.app.model.Turno;

public interface TurnoRepository extends JpaRepository<Turno, Long>{
	
	@Query("SELECT t FROM Turno t WHERE t.idDePelicula = :id AND t.fechaDeFuncion = CURDATE()")
	List<Turno> encontrarTurnoPorIdPelicula(Long id);
	
}

package com.cinepum.app.model;

import java.sql.Date;
import java.sql.Time;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "shifts")
public class Turno {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "id_movie")
	private Long idDePelicula;
	
	@Column(name = "id_cinema_room")
	private Long idDeSala;
	
	@Column(name = "hour")
	private Time horaDeFuncion;
	
	@Column(name = "date")
	private Date fechaDeFuncion;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getIdDePelicula() {
		return idDePelicula;
	}

	public void setIdDePelicula(Long idDePelicula) {
		this.idDePelicula = idDePelicula;
	}

	public Long getIdDeSala() {
		return idDeSala;
	}

	public void setIdDeSala(Long idDeSala) {
		this.idDeSala = idDeSala;
	}

	public Time getHoraDeFuncion() {
		return horaDeFuncion;
	}

	public void setHoraDeFuncion(Time horaDeFuncion) {
		this.horaDeFuncion = horaDeFuncion;
	}

	public Date getFechaDeFuncion() {
		return fechaDeFuncion;
	}

	public void setFechaDeFuncion(Date fechaDeFuncion) {
		this.fechaDeFuncion = fechaDeFuncion;
	}

	@Override
	public String toString() {
		return "Turno [id=" + id + ", idDePelicula=" + idDePelicula + ", idDeSala=" + idDeSala + ", horaDeFuncion="
				+ horaDeFuncion + ", fechaDeFuncion=" + fechaDeFuncion + "]";
	}
	
}

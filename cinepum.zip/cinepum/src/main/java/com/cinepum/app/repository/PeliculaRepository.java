package com.cinepum.app.repository;

//Package JPA Repository
import org.springframework.data.jpa.repository.JpaRepository;

//Model
import com.cinepum.app.model.Pelicula;

public interface PeliculaRepository extends JpaRepository<Pelicula, Long>{
	
}

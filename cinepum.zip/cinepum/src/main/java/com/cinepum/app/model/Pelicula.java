package com.cinepum.app.model;

//Only represent Date without time
import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "movies")
public class Pelicula {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@Column(name = "name")
	private String nombre;
	
	@Column(name = "description")
	private String sipnosis;
	
	@Column(name = "img_path")
	private String rutaDeImagen;
	
	@Column(name = "release_date")
	private Date fechaDeEstreno;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getSipnosis() {
		return sipnosis;
	}

	public void setSipnosis(String sipnosis) {
		this.sipnosis = sipnosis;
	}
	
	public String getRutaDeImagen() {
		return rutaDeImagen;
	}

	public void setRutaDeImagen(String rutaDeImagen) {
		this.rutaDeImagen = rutaDeImagen;
	}

	public Date getFechaDeEstreno() {
		return fechaDeEstreno;
	}

	public void setFechaDeEstreno(Date fechaDeEstreno) {
		this.fechaDeEstreno = fechaDeEstreno;
	}

	@Override
	public String toString() {
		return "Pelicula [id=" + id + ", nombre=" + nombre + ", sipnosis=" + sipnosis + ", rutaDeImagen=" + rutaDeImagen
				+ ", fechaDeEstreno=" + fechaDeEstreno + "]";
	}
	
}

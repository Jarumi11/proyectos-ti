package com.cinepum.app.controller;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.cinepum.app.model.Pelicula;
import com.cinepum.app.repository.PeliculaRepository;

@Controller
public class HomeController {

	@Autowired
	PeliculaRepository peliculaRepository;
	
	@GetMapping("/")
	public String index(Model index) {
		List<Pelicula> peliculas = peliculaRepository.findAll();
		index.addAttribute("peliculas", peliculas);
		return "index";
	}
	
	
}

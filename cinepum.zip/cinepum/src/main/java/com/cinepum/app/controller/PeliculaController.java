package com.cinepum.app.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cinepum.app.model.Pelicula;
import com.cinepum.app.model.Turno;
import com.cinepum.app.repository.PeliculaRepository;
import com.cinepum.app.repository.TurnoRepository;

@Controller
public class PeliculaController {
	
	@Autowired
	PeliculaRepository peliculaRepository;
	
	@Autowired
	TurnoRepository turnoRepository;
	
	//Listamos todas las peliculas
	@GetMapping("/peliculas")
	public String irAPeliculas(Model peliculas) {
		return "peliculas";
	}
	
	//Muestro la pelicula especifica
	@GetMapping("/peliculas/{id}") 
	public String mostrarPelicula(@PathVariable Long id, Model detalle) {
		Optional<Pelicula> peliculaEncontrada = peliculaRepository.findById(id);
		
		//Validamos que la pelicula encontrada no este vacia o exista
		if( peliculaEncontrada.isPresent() ) {
			
			Pelicula pelicula = peliculaEncontrada.get();
			
			//Si encuentra que la pelicula existe, por consecuente encontrara turnos de la misma
			List<Turno> turnos = turnoRepository.encontrarTurnoPorIdPelicula(pelicula.getId());
			
			detalle.addAttribute("pelicula", pelicula);
			detalle.addAttribute("turnos", turnos);
		}else {
			detalle.addAttribute("mensaje", "¡La pelicula no ha sido encontrada! :(");
		}
		
		return "detalle";
	}
	
	
	
	@PostMapping("/peliculas/guardar")
	public ModelAndView guardarPelicula() throws IOException{
		ModelAndView vistaHtml = new ModelAndView();	
		// Return provisional
		return new ModelAndView();
	}
}

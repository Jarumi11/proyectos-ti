package com.cinepum.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class AdministrarController {
	
	@GetMapping("/administrar")
	public String irAdministrar() {
		return "administrar";
	}
	
	
		
}

package com.cinepum.app.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.web.multipart.MultipartFile;

import com.cinepum.app.model.Pelicula;
import com.cinepum.app.repository.PeliculaRepository;

public abstract class PeliculaService implements PeliculaRepository{
	
	public void guardarImagen(MultipartFile imagen, Pelicula pelicula) throws IOException {
		// Obtenemos la ruta actual y en base a eso obtenemos la ruta total
		Path rutaActual = Paths.get(".");
		Path rutaTotal = rutaActual.toAbsolutePath();
		
		// En la entidad actual guardamos la ruta completa de la imagen
		pelicula.setRutaDeImagen(rutaTotal + "/src/main/resources/static/images/movies");
		
		// Obtenemos los bytes de la imagen
		byte[] bytes = imagen.getBytes();
		
		// Obtenemos la ruta completa de la imagen y concatenamos el nombre del archivo para guardarlo en dicha ruta
		Path ruta = Paths.get(pelicula.getRutaDeImagen() + imagen.getOriginalFilename());
		
		// Escribimos sobre nuestro sistema en la ruta y seteamos los bytes (Es decir la imagen)
		Files.write(ruta, bytes);
	}
	
}

package com.cinepum.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinepumApplicationTests {

	@Test
	void contextLoads() {
	}

}
